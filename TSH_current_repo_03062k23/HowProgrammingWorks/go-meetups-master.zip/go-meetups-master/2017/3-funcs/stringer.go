package fmt

type Stringer interface {
	String() string
}

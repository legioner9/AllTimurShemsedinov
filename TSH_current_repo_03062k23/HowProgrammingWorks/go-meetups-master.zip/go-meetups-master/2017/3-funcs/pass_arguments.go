package main

func byValue(s Student)                 {}
func byValue2(s [1]Student)             {}
func byPointer(s *Student)              {}
func byReference(s []Student)           {}
func byReference2(s map[string]Student) {}

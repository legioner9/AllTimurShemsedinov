package main

import "fmt"

func main() {
	// START OMIT
	fmt.Println(len("string"))

	fmt.Println(len("строка"))

	fmt.Println(len("🤷🤷🤷"))
	// END OMIT
}

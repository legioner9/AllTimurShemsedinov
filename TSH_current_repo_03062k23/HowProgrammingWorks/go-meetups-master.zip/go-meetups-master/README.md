## Installing go tools
https://golang.org/doc/install

## Installing present cmd tool

```bash
go get golang.org/x/tools/cmd/present
```

## Starting slides server
``` bash
present
```

## Watch slides
http://127.0.0.1:3999

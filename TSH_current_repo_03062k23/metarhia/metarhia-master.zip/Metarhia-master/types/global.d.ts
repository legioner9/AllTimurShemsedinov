declare global {
  namespace metarhia {}

  namespace api {}

  namespace lib {}

  namespace domain {}

  namespace db {}
}

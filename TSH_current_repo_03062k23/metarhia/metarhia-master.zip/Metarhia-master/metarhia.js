'use strict';

const metarhia = {};
module.exports = metarhia;

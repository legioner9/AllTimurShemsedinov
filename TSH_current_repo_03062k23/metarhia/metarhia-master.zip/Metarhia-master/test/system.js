'use strict';

console.log('Test stub');
